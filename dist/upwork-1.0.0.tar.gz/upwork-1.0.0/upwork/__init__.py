from .scraper import Scraper, Talent
